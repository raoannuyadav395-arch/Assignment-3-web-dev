const express = require('express');
const router = express.Router();
const {
  createProduct,
  getProducts,
  getLowStockReport,
  getCategorySummary,
  getProductById,
  updateProduct,
  adjustStock,
  deleteProduct,
} = require('../controllers/productController');

router.get('/low-stock', getLowStockReport);
router.get('/summary', getCategorySummary);

router.route('/').get(getProducts).post(createProduct);

router.patch('/:id/stock', adjustStock);

router.route('/:id').get(getProductById).put(updateProduct).delete(deleteProduct);

module.exports = router;